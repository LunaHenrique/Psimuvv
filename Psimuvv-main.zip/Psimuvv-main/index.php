<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta lang="pt-BR">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css\estilo.css">
    <script src="js/bootstrap.bundle.min.js"></script>
    <title>Psimuvv</title>
</head>
<body>
    <?php
        session_start();
        include 'php/cabecalho.php';
    ?>

    <!--
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-6">
                <h2 class="mt-5" style="text-align: justify;">Violência Doméstica</h2>
                <p class="text-justify text-wrap">Infelizmente, a violência doméstica e familiar contra a mulher ainda é uma realidade no Brasil, já que, por exemplo, 57% dos brasileiros conhecem alguma mulher que foi vítima de ameaça de morte pelo atual parceiro. Nesses casos, a violência pode ser entendida como qualquer ação ou omissão influenciada pelo gênero da vítima que lhe cause  morte, lesão, sofrimento físico, sexual ou psicológico, além de danos morais ou patrimoniais. </p>
                <div class="d-flex justify-content-center">
                    <img src="imagens\violencia-domestica.png" alt="Grafico" style="width:500px;">
                </div>

                <hr class="d-sm-none">
            </div>

            <div class="col-sm-6">

                <div class="d-flex justify-content-center">
                    <img class="mt-5 " src="imagens\por-que-terapia.png" alt="Grafico" style="width:500px;">
                </div>

                <h2>Por que fazer terapia?</h2>
                <p>Muitas pessoas acham que terapia é “coisa de doido”, “frescura” ou só uma “conversinha”, mas terapia é um ambiente livre de julgamentos e seguro em que você e seu pscicoterapeuta/psicólogo caminharão juntos em direção à melhora da sua saúde mental e qualidade de vida. </p>
            </div>
        </div>
        <div class="row">
            <div class="container d-flex justify-content-center">
                <a href="#" class="bg-primary text-secondary btn btn-dark btn-lg my-5 btn-outline-light"> Consulta</a>
            </div>
        </div>
    </div>
    -->

<!-- DEPOIMENTOS -->
<section id="depoimentos" class="container my-5">
    <div class="row">
            <div class="col-sm-12">
                <h2>Depoimentos</h2>
                
        <!-- CARROSEL DOS DEPOIMENTOS, MUITO COMPLICADO CUIDADO PRA NÃO QUEBRAR -->
        <div id="depoimentos" class="carousel slide px-5" data-bs-ride="carousel">

            <!-- Indicadores/Pontinhos -->
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#depoimentos" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#depoimentos" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#depoimentos" data-bs-slide-to="2"></button>
            </div>

            <!-- Os Slides -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div id="card-depoimentos" class="card mb-3">
                        <div id="card-depoimentos" class="card-body"> 
                            <h4>Anonima</h4>
                            <p>Depois que as consultas começaram a minha qualidade de vida melhorou em 100%, graças às consultas pude compreender que eu não tive culpa nenhuma pela violência que sofri. Os psicólogos são muito acolhedores e atenciosos, e eu sou muito grata por terem me ouvido. Se você está com medo de se consultar, fique tranquila, aqui você será acolhida e ajudada! Muito obrigado por toda a ajuda, super recomendo a plataforma! </p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div id="card-depoimentos" class="card mb-3">
                        <div id="card-depoimentos" class="card-body"> 
                            <h4>Anonima</h4>
                            <p>Depois que as consultas começaram a minha qualidade de vida melhorou em 100%, graças às consultas pude compreender que eu não tive culpa nenhuma pela violência que sofri. Os psicólogos são muito acolhedores e atenciosos, e eu sou muito grata por terem me ouvido. Se você está com medo de se consultar, fique tranquila, aqui você será acolhida e ajudada! Muito obrigado por toda a ajuda, super recomendo a plataforma! </p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div id="card-depoimentos" class="card mb-3">
                        <div id="card-depoimentos" class="card-body"> 
                            <h4>Anonima</h4>
                            <p>Depois que as consultas começaram a minha qualidade de vida melhorou em 100%, graças às consultas pude compreender que eu não tive culpa nenhuma pela violência que sofri. Os psicólogos são muito acolhedores e atenciosos, e eu sou muito grata por terem me ouvido. Se você está com medo de se consultar, fique tranquila, aqui você será acolhida e ajudada! Muito obrigado por toda a ajuda, super recomendo a plataforma! </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Controles de Esquerda e Direita -->
            <button class="carousel-control-prev" type="button" data-bs-target="#depoimentos" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#depoimentos" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
            </div>
        </div>
    </div>
</section>

<!-- SOBRE NÓS -->
<section id="sobre-nos" class="container my-5">
    <div class="row">
        <div class="col-sm-12">
            <h2>Sobre Nós</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <p class="sobre-nos-texto">O Psimuvv foi desenvolvido a partir do trabalho de conclusão de cinco alunos, no âmbito da disciplina de Projeto Integrador, do curso técnico de Informática para Internet do Instituto Federal de São Paulo - São Miguel Paulista. A ideia do projeto foi retribuir à comunidade exterior o conhecimento adquirido na instituição, bem como  exercer os aprendizados obtidos nas disciplinas técnicas do curso. Para isso, a plataforma foi pensada para atender psicologicamente, de modo gratuito e a distância, mulheres vítimas de violência doméstica e familiar a fim de que essas possam recuperar sua saúde mental. </p>
        </div>
        <div class="col-sm-3">
            <div id="card-sobre-nos" class="card mb-3">
                <div id="card-sobre-nos" class="card-body"> 
                    <h4 class="card-title">Links Úteis</h4>
                    <a class="card-link" href="https://atosoficiais.com.br/cfp/resolucao-do-exercicio-profissional-n-4-2020-dispoe-sobre-regulamentacao-de-servicos-psicologicos-prestados-por-meio-de-tecnologia-da-informacao-e-da-comunicacao-durante-a-pandemia-do-covid-19">
                        Resolução CFP n°04/2020</a> <br>
                    <a class="card-link" href="https://mdh.metasix.solutions/portal/servicos/informacao?t=86&servico=235" >
                        Ligue 180 - Canal de denúncia</a> <br>
                    <a class="card-link" href="https://cadastro.cfp.org.br/" >
                        Consulte o CRP do profissional</a> <br>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div id="card-sobre-nos" class="card">
                <div id="card-sobre-nos" class="card-body"> 
                    <h4 class="card-title">Membras do Desenvolvimento</h4>
                    <ul>
                        <li>Ana Carolina</li>
                        <li>Laura Martins</li>
                        <li>Lucas Henrique</li>
                        <li>Sarah Fernandes</li>
                        <li>Iury Santos</li>
                        <li>Lucas Benati</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


</body>
</html>